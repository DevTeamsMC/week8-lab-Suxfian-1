﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_LAB_HANGMAN_LAST
{
    public class Question
    {
        public string Word { get; set; }
        public string Hint { get; set; }
        public string Category { get; set; }  // Örn: Tarih, Matematik
        public string Difficulty { get; set; } // Örn: Kolay, Orta, Zor
    }

}
