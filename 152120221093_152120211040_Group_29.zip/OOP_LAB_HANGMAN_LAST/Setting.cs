﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_LAB_HANGMAN_LAST
{
    public static class GameSettings
    {
        public static string SelectedCategory = "Karma";
        public static string SelectedDifficulty = "Kolay";
        public static int GameTime = 30;
    }

}
