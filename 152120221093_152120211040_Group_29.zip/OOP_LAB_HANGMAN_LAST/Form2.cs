﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace OOP_LAB_HANGMAN_LAST
{
    public partial class Form2 : Form
    {
        HashSet<char> dogruHarfler = new HashSet<char>();
        HashSet<char> yanlisHarfler = new HashSet<char>();

        string secilenKelime = "";
        string gosterilenKelime = "";
        string secilenKategori = "";
        string secilenSeviye = "";
        int hataSayisi = 0;
        int puan = 100;
        Timer oyunSuresiTimer;
        int kalanSure = 30;

        public static string kategori;
        public static string seviye;
        public static int sure;

        Dictionary<string, List<(string kelime, string ipucu, string zorluk)>> soruHavuzu;

        public Form2()
        {
            InitializeComponent();
            oyunSuresiTimer = new Timer();
            oyunSuresiTimer.Interval = 1000;
            oyunSuresiTimer.Tick += timer1_Tick;

            soruHavuzu = new Dictionary<string, List<(string, string, string)>>()
            {
                ["Tarih"] = new List<(string, string, string)>
            {
                ("hitit", "Anadolu'da kurulmuş ilk büyük uygarlıklardan.", "Kolay"),
                ("roma", "Batı Avrupa'da kurulmuş antik imparatorluk.", "Kolay"),
                ("napolyon", "Fransız askeri lider ve imparator.", "Orta"),
                ("sezar", "veni, vidi, vici sözüyle tanınır.", "Orta"),
                ("kavimlergöçü", "Avrupa'nın siyasi yapısını değiştiren büyük hareket.", "Zor"),
                ("babil", "Asma bahçeleriyle ünlü antik şehir.", "Kolay"),
                ("mezopotamya", "Tarihte bilinen ilk yazının bulunduğu bölge.", "Zor"),
                ("hitler", "2. Dünya Savaşı'nda Almanya'nın lideri.", "Kolay"),
                ("truva", "Tahta at hikayesiyle bilinen antik kent.", "Orta"),
                ("inkalar", "Güney Amerika'da büyük bir medeniyet.", "Zor"),
                ("fatih", "İstanbul'u fetheden Osmanlı padişahı.", "Kolay"),
                ("yavuz", "Doğu seferleriyle tanınan Osmanlı padişahı.", "Orta"),
                ("moğollar", "Cengiz Han'ın kurduğu büyük imparatorluk.", "Zor"),
                ("attila", "Avrupa'yı titreten Hun lideri.", "Orta"),
                ("bizans", "İstanbul merkezli eski Hristiyan imparatorluk.", "Kolay"),
                ("haçlı", "Orta Çağ'da yapılan dini savaşlar.", "Kolay"),
                ("kanuni", "16. yüzyılda Osmanlı'nın en güçlü dönemini yaşatan padişah.", "Kolay"),
                ("sultan", "Osmanlı'da padişah anlamına gelir.", "Kolay"),
                ("celali", "Osmanlı'daki büyük isyanlardan biri.", "Zor"),
                ("hilafet", "İslam dünyasının dini liderliği.", "Orta")
            },
                ["Coğrafya"] = new List<(string, string, string)>
            {
                ("asya", "Yüzölçümü en büyük kıta.", "Kolay"),
                ("amazon", "Dünyanın en büyük orman alanı.", "Kolay"),
                ("everest", "Dünyanın en yüksek dağı.", "Kolay"),
                ("sibirya", "Dünyanın en soğuk yerlerinden biri.", "Orta"),
                ("sahara", "En büyük sıcak çöl.", "Kolay"),
                ("atlas", "Harita kitabı.", "Kolay"),
                ("volkan", "Yanardağ başka adı.", "Kolay"),
                ("iklim", "Bir bölgedeki uzun süreli hava koşulları.", "Kolay"),
                ("deltalar", "Nehirlerin denize döküldüğü yerlerdir.", "Orta"),
                ("kongo", "Afrika'nın büyük nehirlerinden biri.", "Orta"),
                ("tundra", "Soğuk ve bitki örtüsü az olan biyom.", "Zor"),
                ("ekvator", "Dünyanın en geniş enlemi.", "Kolay"),
                ("kuzeykutbu", "Dünyanın en üst noktası.", "Orta"),
                ("oksijen", "Havadaki hayati gaz.", "Kolay"),
                ("tektonik", "Yer kabuğu hareketleriyle ilgili.", "Zor"),
                ("kıta", "Karasal büyük kara parçaları.", "Kolay"),
                ("grönland", "En büyük ada.", "Orta"),
                ("japonya", "Pasifikte yer alan volkanik ada ülkesi.", "Kolay"),
                ("türkiye", "Asya ve Avrupa kıtaları arasında köprü.", "Kolay"),
                ("okyanus", "En büyük su kütleleri.", "Kolay")
            },
                ["Matematik"] = new List<(string, string, string)>
            {
                ("pi", "Yaklaşık değeri 3.14 olan sabit.", "Kolay"),
                ("asal", "Sadece 1 ve kendisine bölünen sayılar.", "Kolay"),
                ("logaritma", "Çarpma işleminin tersidir.", "Zor"),
                ("faktöriyel", "n! olarak gösterilir.", "Orta"),
                ("integral", "Alan hesabı yapılan matematiksel işlem.", "Zor"),
                ("çarpan", "Bir sayıyı bölen sayılar.", "Kolay"),
                ("denklem", "Bir eşitlik içeren matematiksel ifade.", "Kolay"),
                ("limit", "Bir fonksiyonun belirli noktaya yaklaşımı.", "Zor"),
                ("oran", "İki niceliğin birbirine bölümü.", "Kolay"),
                ("üslü", "Bir sayının kendisiyle tekrarlı çarpımı.", "Orta"),
                ("karekök", "Bir sayının karesini veren değer.", "Kolay"),
                ("hipotenüs", "Dik üçgende en uzun kenar.", "Orta"),
                ("matris", "Sayıların düzenli şekilde yazılması.", "Zor"),
                ("vade", "Süreli ödeme terimi.", "Kolay"),
                ("açı", "İki doğru arasındaki açıklık.", "Kolay"),
                ("paralel", "Birbirine eşit uzaklıkta iki doğru.", "Kolay"),
                ("kümeler", "Ortak özellik taşıyan nesneler topluluğu.", "Kolay"),
                ("fonksiyon", "Her x için bir y değeri atayan ifade.", "Orta"),
                ("karmaşık", "Gerçek ve sanal sayı birleşimi.", "Zor"),
                ("asalçarpan", "Bir sayının sadece asal olan bölenleri.", "Orta")
            },
                ["Genel Kültür"] = new List<(string, string, string)>
            {
                ("türkiye", "Ankara başkentidir.", "Kolay"),
                ("ankara", "Türkiye'nin başkenti.", "Kolay"),
                ("ataturk", "Türkiye Cumhuriyeti'nin kurucusu.", "Kolay"),
                ("google", "Popüler arama motoru.", "Kolay"),
                ("microsoft", "Windows işletim sistemini geliştiren firma.", "Kolay"),
                ("internet", "Bilgi ağlarının genel adı.", "Kolay"),
                ("nasa", "Amerikan uzay ajansı.", "Kolay"),
                ("titanik", "Batmasıyla ünlü yolcu gemisi.", "Kolay"),
                ("film", "Sinema salonlarında izlenir.", "Kolay"),
                ("kitap", "Okumak için yazılmış eser.", "Kolay"),
                ("sanat", "Estetik ve yaratıcılık ürünü.", "Orta"),
                ("robot", "Makine ile çalışan insan benzeri araç.", "Orta"),
                ("müzik", "Seslerle yapılan sanat dalı.", "Kolay"),
                ("nota", "Müziğin yazılı ifadesi.", "Kolay"),
                ("sinema", "Filmlerin gösterildiği sanat dalı.", "Kolay"),
                ("eurovision", "Avrupa şarkı yarışması.", "Orta"),
                ("kripto", "Dijital para birimi.", "Zor"),
                ("yapayzeka", "Makine öğrenimiyle karar alan sistem.", "Zor"),
                ("astronomi", "Gök cisimleri bilimi.", "Orta"),
                ("uzay", "Dünya'nın dışı.", "Kolay")
            }
            };
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            kalanSure = sure;
            secilenKategori = kategori;
            secilenSeviye = seviye;
            lblSure.Text = $"Süre: {kalanSure}";
            lblAyarlar.Text = $"Süre: {kalanSure} - Kategori: {secilenKategori} - Seviye: {secilenSeviye}";

            var uygunSorular = soruHavuzu[secilenKategori].Where(x => x.zorluk == secilenSeviye).ToList();
            Random rnd = new Random();
            int index = rnd.Next(uygunSorular.Count);
            (string kelime, string ipucu, string zorluk) = uygunSorular[index];

            secilenKelime = kelime;
            lblIpucu.Text = ipucu;
            lblIpucu.Visible = false;

            gosterilenKelime = new string('_', secilenKelime.Length);
            lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
            lblUzunluk.Text = "Kelime Uzunluğu: " + secilenKelime.Length;
            lblPuan.Text = "Puan: 100";
            pictureBox1.Image = Image.FromFile("images/man-1.jpg");

            oyunSuresiTimer.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            kalanSure--;
            lblSure.Text = "Süre: " + kalanSure;

            if (kalanSure <= 0)
            {
                oyunSuresiTimer.Stop();
                this.BackColor = Color.Red;
                MessageBox.Show("Süre bitti! Kaybettiniz.\nKelime: " + secilenKelime);
                btnTahmin.Enabled = false;
            }
        }

        private void btnIpucu_Click(object sender, EventArgs e)
        {
            MessageBox.Show(lblIpucu.Text, "İpucu", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnTahmin_Click(object sender, EventArgs e)
        {
            string girilen = txtHarf.Text.ToLower().Trim();
            txtHarf.Clear();

            if (girilen.Length != 1 || !char.IsLetter(girilen[0]))
            {
                MessageBox.Show("Lütfen geçerli bir harf girin.");
                return;
            }

            char harf = girilen[0];

            if (dogruHarfler.Contains(harf) || yanlisHarfler.Contains(harf))
            {
                MessageBox.Show("Bu harfi zaten girdiniz!");
                return;
            }

            if (secilenKelime.Contains(harf))
            {
                dogruHarfler.Add(harf);
                char[] temp = gosterilenKelime.ToCharArray();
                for (int i = 0; i < secilenKelime.Length; i++)
                {
                    if (secilenKelime[i] == harf)
                        temp[i] = harf;
                }

                gosterilenKelime = new string(temp);
                lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());

                if (!gosterilenKelime.Contains('_'))
                {
                    oyunSuresiTimer.Stop();
                    this.BackColor = Color.LightGreen;
                    MessageBox.Show("Tebrikler, kazandınız!");
                    btnTahmin.Enabled = false;
                }
            }
            else
            {
                yanlisHarfler.Add(harf);
                hataSayisi++;
                puan -= 10;
                lblPuan.Text = "Puan: " + puan;
                lblYanlis.Text += harf + " ";

                string resimYolu = $"images/man-{hataSayisi + 1}.jpg";
                if (File.Exists(resimYolu))
                    pictureBox1.Image = Image.FromFile(resimYolu);

                if (hataSayisi >= 9)
                {
                    oyunSuresiTimer.Stop();
                    this.BackColor = Color.Red;
                    MessageBox.Show("Kaybettiniz. Kelime: " + secilenKelime);
                    btnTahmin.Enabled = false;
                }
            }
        }

        private void txtHarf_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Back) return;
            if (txtHarf.Text.Length >= 1) { e.Handled = true; return; }
            if (!char.IsLetter(e.KeyChar)) e.Handled = true;
        }

        private void btnBitir_Click(object sender, EventArgs e)
        {
            DialogResult sonuc = MessageBox.Show("Oyunu bitirmek istiyor musunuz?", "Çıkış", MessageBoxButtons.YesNo);
            if (sonuc == DialogResult.Yes)
            {
                MessageBox.Show("Oyun sonlandırıldı.");
                this.Close();
            }
        }
    }
}
