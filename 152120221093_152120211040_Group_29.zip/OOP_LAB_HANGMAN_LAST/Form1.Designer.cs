﻿namespace OOP_LAB_HANGMAN_LAST
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.playBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbTarih = new System.Windows.Forms.RadioButton();
            this.rbMatematik = new System.Windows.Forms.RadioButton();
            this.rbCografya = new System.Windows.Forms.RadioButton();
            this.rbKarma = new System.Windows.Forms.RadioButton();
            this.rbGenelKultur = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // playBtn
            // 
            this.playBtn.BackColor = System.Drawing.Color.YellowGreen;
            this.playBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.playBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.playBtn.Location = new System.Drawing.Point(344, 208);
            this.playBtn.Name = "playBtn";
            this.playBtn.Size = new System.Drawing.Size(121, 52);
            this.playBtn.TabIndex = 1;
            this.playBtn.Text = "BAŞLA";
            this.playBtn.UseVisualStyleBackColor = false;
            this.playBtn.Click += new System.EventHandler(this.playBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.YellowGreen;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(570, 182);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "GAME";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SaddleBrown;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button1.Location = new System.Drawing.Point(504, 337);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(205, 42);
            this.button1.TabIndex = 3;
            this.button1.Text = "Oyun Ayarları";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox1.Controls.Add(this.rbGenelKultur);
            this.groupBox1.Controls.Add(this.rbKarma);
            this.groupBox1.Controls.Add(this.rbCografya);
            this.groupBox1.Controls.Add(this.rbMatematik);
            this.groupBox1.Controls.Add(this.rbTarih);
            this.groupBox1.Location = new System.Drawing.Point(100, 182);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(202, 162);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Kategoriler";
            // 
            // rbTarih
            // 
            this.rbTarih.AutoSize = true;
            this.rbTarih.Location = new System.Drawing.Point(22, 26);
            this.rbTarih.Name = "rbTarih";
            this.rbTarih.Size = new System.Drawing.Size(59, 20);
            this.rbTarih.TabIndex = 0;
            this.rbTarih.TabStop = true;
            this.rbTarih.Text = "Tarih";
            this.rbTarih.UseVisualStyleBackColor = true;
            // 
            // rbMatematik
            // 
            this.rbMatematik.AutoSize = true;
            this.rbMatematik.Location = new System.Drawing.Point(22, 52);
            this.rbMatematik.Name = "rbMatematik";
            this.rbMatematik.Size = new System.Drawing.Size(90, 20);
            this.rbMatematik.TabIndex = 1;
            this.rbMatematik.TabStop = true;
            this.rbMatematik.Text = "Matematik";
            this.rbMatematik.UseVisualStyleBackColor = true;
            // 
            // rbCografya
            // 
            this.rbCografya.AutoSize = true;
            this.rbCografya.Location = new System.Drawing.Point(22, 78);
            this.rbCografya.Name = "rbCografya";
            this.rbCografya.Size = new System.Drawing.Size(83, 20);
            this.rbCografya.TabIndex = 2;
            this.rbCografya.TabStop = true;
            this.rbCografya.Text = "Coğrafya";
            this.rbCografya.UseVisualStyleBackColor = true;
            // 
            // rbKarma
            // 
            this.rbKarma.AutoSize = true;
            this.rbKarma.Location = new System.Drawing.Point(22, 104);
            this.rbKarma.Name = "rbKarma";
            this.rbKarma.Size = new System.Drawing.Size(67, 20);
            this.rbKarma.TabIndex = 3;
            this.rbKarma.TabStop = true;
            this.rbKarma.Text = "Karma";
            this.rbKarma.UseVisualStyleBackColor = true;
            // 
            // rbGenelKultur
            // 
            this.rbGenelKultur.AutoSize = true;
            this.rbGenelKultur.Location = new System.Drawing.Point(22, 130);
            this.rbGenelKultur.Name = "rbGenelKultur";
            this.rbGenelKultur.Size = new System.Drawing.Size(99, 20);
            this.rbGenelKultur.TabIndex = 4;
            this.rbGenelKultur.TabStop = true;
            this.rbGenelKultur.Text = "Genel Kültür";
            this.rbGenelKultur.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::OOP_LAB_HANGMAN_LAST.Properties.Resources.WhatsApp_Görsel_2025_04_24_saat_12_01_16_f8c5085c;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.playBtn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button playBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbGenelKultur;
        private System.Windows.Forms.RadioButton rbKarma;
        private System.Windows.Forms.RadioButton rbCografya;
        private System.Windows.Forms.RadioButton rbMatematik;
        private System.Windows.Forms.RadioButton rbTarih;
    }
}

