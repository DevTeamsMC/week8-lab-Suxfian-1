﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_LAB_HANGMAN_LAST
{
    public partial class Form3: Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnAyarlarıKaydet_Click(object sender, EventArgs e)
        {
            GameSettings.SelectedCategory = cmbKategori.SelectedItem.ToString();
            GameSettings.SelectedDifficulty = cmbZorluk.SelectedItem.ToString();
            GameSettings.GameTime = (int)nudSure.Value;

            MessageBox.Show("Ayarlar kaydedildi.");
            this.Close();
        }
    }
}
