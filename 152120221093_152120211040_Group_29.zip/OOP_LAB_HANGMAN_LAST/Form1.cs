﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP_LAB_HANGMAN_LAST
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static string secilenKategori = "Genel Kültür";
        private void playBtn_Click(object sender, EventArgs e)
        {
            if (rbTarih.Checked) secilenKategori = "Tarih";
            else if (rbCografya.Checked) secilenKategori = "Coğrafya";
            else if (rbMatematik.Checked) secilenKategori = "Matematik";
            else if (rbGenelKultur.Checked) secilenKategori = "Genel Kültür";
            else if (rbKarma.Checked) secilenKategori = "Karma";

            Form2 play = new Form2();
            play.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 ayarFormu = new Form3();
            ayarFormu.ShowDialog(); // Modal aç
        }
    }
}
