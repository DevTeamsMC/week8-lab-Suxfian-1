﻿namespace OOP_LAB_HANGMAN_LAST
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblIpucu = new System.Windows.Forms.Label();
            this.lblSure = new System.Windows.Forms.Label();
            this.btnIpucu = new System.Windows.Forms.Button();
            this.lblPuan = new System.Windows.Forms.Label();
            this.btnBitir = new System.Windows.Forms.Button();
            this.btnTahmin = new System.Windows.Forms.Button();
            this.txtHarf = new System.Windows.Forms.TextBox();
            this.lblYanlis = new System.Windows.Forms.Label();
            this.lblUzunluk = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblKelime = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblAyarlar = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblIpucu);
            this.groupBox1.Controls.Add(this.lblSure);
            this.groupBox1.Controls.Add(this.btnIpucu);
            this.groupBox1.Controls.Add(this.lblPuan);
            this.groupBox1.Controls.Add(this.btnBitir);
            this.groupBox1.Controls.Add(this.btnTahmin);
            this.groupBox1.Controls.Add(this.txtHarf);
            this.groupBox1.Controls.Add(this.lblYanlis);
            this.groupBox1.Controls.Add(this.lblUzunluk);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Location = new System.Drawing.Point(461, 50);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(307, 352);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Oyun Alanı";
            // 
            // lblIpucu
            // 
            this.lblIpucu.AutoSize = true;
            this.lblIpucu.Location = new System.Drawing.Point(112, 268);
            this.lblIpucu.Name = "lblIpucu";
            this.lblIpucu.Size = new System.Drawing.Size(44, 16);
            this.lblIpucu.TabIndex = 9;
            this.lblIpucu.Text = "label1";
            this.lblIpucu.Visible = false;
            // 
            // lblSure
            // 
            this.lblSure.AutoSize = true;
            this.lblSure.Location = new System.Drawing.Point(245, 19);
            this.lblSure.Name = "lblSure";
            this.lblSure.Size = new System.Drawing.Size(47, 16);
            this.lblSure.TabIndex = 8;
            this.lblSure.Text = "zaman";
            // 
            // btnIpucu
            // 
            this.btnIpucu.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnIpucu.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnIpucu.Location = new System.Drawing.Point(130, 305);
            this.btnIpucu.Name = "btnIpucu";
            this.btnIpucu.Size = new System.Drawing.Size(28, 41);
            this.btnIpucu.TabIndex = 7;
            this.btnIpucu.Text = "💡";
            this.btnIpucu.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnIpucu.UseVisualStyleBackColor = false;
            this.btnIpucu.Click += new System.EventHandler(this.btnIpucu_Click);
            // 
            // lblPuan
            // 
            this.lblPuan.AutoSize = true;
            this.lblPuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblPuan.Location = new System.Drawing.Point(25, 310);
            this.lblPuan.Name = "lblPuan";
            this.lblPuan.Size = new System.Drawing.Size(78, 25);
            this.lblPuan.TabIndex = 6;
            this.lblPuan.Text = "PUAN: ";
            // 
            // btnBitir
            // 
            this.btnBitir.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnBitir.Location = new System.Drawing.Point(164, 305);
            this.btnBitir.Name = "btnBitir";
            this.btnBitir.Size = new System.Drawing.Size(128, 41);
            this.btnBitir.TabIndex = 5;
            this.btnBitir.Text = "OYUNU BİTİR";
            this.btnBitir.UseVisualStyleBackColor = false;
            this.btnBitir.Click += new System.EventHandler(this.btnBitir_Click);
            // 
            // btnTahmin
            // 
            this.btnTahmin.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnTahmin.Location = new System.Drawing.Point(112, 231);
            this.btnTahmin.Name = "btnTahmin";
            this.btnTahmin.Size = new System.Drawing.Size(114, 30);
            this.btnTahmin.TabIndex = 4;
            this.btnTahmin.Text = "TAHMİN ET!";
            this.btnTahmin.UseVisualStyleBackColor = false;
            this.btnTahmin.Click += new System.EventHandler(this.btnTahmin_Click);
            // 
            // txtHarf
            // 
            this.txtHarf.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtHarf.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtHarf.Location = new System.Drawing.Point(64, 231);
            this.txtHarf.Name = "txtHarf";
            this.txtHarf.Size = new System.Drawing.Size(42, 30);
            this.txtHarf.TabIndex = 3;
            // 
            // lblYanlis
            // 
            this.lblYanlis.AutoSize = true;
            this.lblYanlis.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblYanlis.Location = new System.Drawing.Point(48, 169);
            this.lblYanlis.Name = "lblYanlis";
            this.lblYanlis.Size = new System.Drawing.Size(168, 25);
            this.lblYanlis.TabIndex = 2;
            this.lblYanlis.Text = "Yanlış Tahminler: ";
            // 
            // lblUzunluk
            // 
            this.lblUzunluk.AutoSize = true;
            this.lblUzunluk.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblUzunluk.Location = new System.Drawing.Point(48, 131);
            this.lblUzunluk.Name = "lblUzunluk";
            this.lblUzunluk.Size = new System.Drawing.Size(171, 25);
            this.lblUzunluk.TabIndex = 1;
            this.lblUzunluk.Text = "Kelime Uzunluğu: ";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Controls.Add(this.lblKelime);
            this.panel1.Location = new System.Drawing.Point(30, 41);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 51);
            this.panel1.TabIndex = 0;
            // 
            // lblKelime
            // 
            this.lblKelime.AutoSize = true;
            this.lblKelime.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKelime.Location = new System.Drawing.Point(55, 10);
            this.lblKelime.Name = "lblKelime";
            this.lblKelime.Size = new System.Drawing.Size(102, 32);
            this.lblKelime.TabIndex = 0;
            this.lblKelime.Text = "_ _ _ _ ";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::OOP_LAB_HANGMAN_LAST.Properties.Resources.man_01;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(418, 426);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblAyarlar
            // 
            this.lblAyarlar.AutoSize = true;
            this.lblAyarlar.Location = new System.Drawing.Point(588, 22);
            this.lblAyarlar.Name = "lblAyarlar";
            this.lblAyarlar.Size = new System.Drawing.Size(44, 16);
            this.lblAyarlar.TabIndex = 2;
            this.lblAyarlar.Text = "label1";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblAyarlar);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblKelime;
        private System.Windows.Forms.Button btnIpucu;
        private System.Windows.Forms.Label lblPuan;
        private System.Windows.Forms.Button btnBitir;
        private System.Windows.Forms.Button btnTahmin;
        private System.Windows.Forms.TextBox txtHarf;
        private System.Windows.Forms.Label lblYanlis;
        private System.Windows.Forms.Label lblUzunluk;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblSure;
        private System.Windows.Forms.Label lblIpucu;
        private System.Windows.Forms.Label lblAyarlar;
    }
}