﻿using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using OOP_LAB_HANGMAN_LAST;

public static class QuestionLoader
{
    public static List<Question> LoadQuestions(string path)
    {
        string json = File.ReadAllText(path);
        return JsonConvert.DeserializeObject<List<Question>>(json);
    }
}
